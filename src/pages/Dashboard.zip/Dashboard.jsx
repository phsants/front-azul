import React, { useEffect, useState } from "react";
import Layout from "../components/Layout";
import { useFiltroVoos } from "../hooks/useFiltroVoos";
import { CardIndicador } from "../components/CardIndicador";
import { GraficosDashboard } from "../components/GraficosDashboard";
import { FiltrosVoos } from "../components/FiltrosVoos";
import { TabelaVoos } from "../components/TabelaVoos";
import { ModalDetalhes } from "../components/ModalDetalhes";
import { Plane, DollarSign, TrendingDown, MapPin } from "lucide-react";

export default function Dashboard() {
  const [voos, setVoos] = useState([]);
  const { filtros, atualizarFiltro, dadosFiltrados } = useFiltroVoos(voos);
  const [dadosSelecionados, setDadosSelecionados] = useState(null);

  // 🔥 Carrega os voos da API
  useEffect(() => {
    const fetchVoos = async () => {
      const token = localStorage.getItem("token");

      if (!token) {
        console.error("Token não encontrado. Redirecionando...");
        window.location.href = "/login";
        return;
      }

      try {
        const response = await fetch("http://localhost:5000/api/voos", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        const data = await response.json();

        if (response.ok) {
          setVoos(data);
        } else {
          console.error("Erro na API:", data);
          alert(data.error || "Erro ao buscar voos.");
        }
      } catch (error) {
        console.error("Erro de comunicação com a API:", error);
        alert("Erro de comunicação com o servidor.");
      }
    };

    fetchVoos();
  }, []);

  const handleRowClick = (dados) => {
    setDadosSelecionados(dados);
  };

  // 🔥 Indicadores
  const totalVoos = dadosFiltrados.length;

  const precos = dadosFiltrados.map((v) => v.preco).filter(Boolean);
  const mediaPreco = precos.length
    ? (precos.reduce((a, b) => a + b, 0) / precos.length).toFixed(2)
    : 0;
  const menorPreco = precos.length ? Math.min(...precos) : 0;

  const contagemDestinos = dadosFiltrados.reduce((acc, v) => {
    acc[v.destino] = (acc[v.destino] || 0) + 1;
    return acc;
  }, {});

  const destinoPopular =
    Object.entries(contagemDestinos).sort((a, b) => b[1] - a[1])[0]?.[0] ||
    "N/A";

  return (
    <Layout>
      <h1 className="text-2xl font-bold text-blue-600 mb-4">
        Dashboard de Voos
      </h1>

      {/* 🔥 Cards */}
      <div className="flex gap-4 flex-wrap mb-8">
        <CardIndicador
          titulo="Total de Voos"
          valor={totalVoos}
          icone={<Plane />}
          cor="blue"
        />
        <CardIndicador
          titulo="Média de Preço"
          valor={`R$ ${mediaPreco}`}
          icone={<DollarSign />}
          cor="green"
        />
        <CardIndicador
          titulo="Menor Preço"
          valor={`R$ ${menorPreco}`}
          icone={<TrendingDown />}
          cor="green"
        />
        <CardIndicador
          titulo="Destino + Buscado"
          valor={destinoPopular}
          icone={<MapPin />}
          cor="blue"
        />
      </div>

      {/* 🔥 Filtros */}
      <FiltrosVoos
        filtros={filtros}
        atualizarFiltro={atualizarFiltro}
        voos={voos}
      />

      {/* 🔥 Gráficos */}
      <GraficosDashboard dados={dadosFiltrados} />

      {/* 🔥 Tabela */}
      <TabelaVoos dados={dadosFiltrados} onRowClick={handleRowClick} />

      {/* 🔥 Modal */}
      <ModalDetalhes
        aberto={!!dadosSelecionados}
        onClose={() => setDadosSelecionados(null)}
        dados={dadosSelecionados}
      />
    </Layout>
  );
}
