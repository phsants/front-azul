import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  BarElement,
} from "chart.js";
import { Line, Bar } from "react-chartjs-2";

// 🔥 Registra os componentes do ChartJS
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export function GraficosDashboard({ dados }) {
  const destinos = [...new Set(dados.map((v) => v.destino))];
  const precoPorDestino = destinos.map(
    (dest) =>
      dados
        .filter((v) => v.destino === dest)
        .reduce((acc, v) => acc + (v.preco || 0), 0) /
      dados.filter((v) => v.destino === dest).length
  );

  const lineData = {
    labels: destinos,
    datasets: [
      {
        label: "Média de Preço por Destino",
        data: precoPorDestino,
        borderColor: "#2563eb",
        backgroundColor: "#2563eb",
      },
    ],
  };

  const barData = {
    labels: destinos,
    datasets: [
      {
        label: "Qtd de Voos por Destino",
        data: destinos.map(
          (dest) => dados.filter((v) => v.destino === dest).length
        ),
        backgroundColor: "#22c55e",
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-xl shadow p-4">
        <h2 className="text-lg font-bold mb-4 text-blue-600">
          Média de Preço por Destino
        </h2>
        <Line data={lineData} />
      </div>

      <div className="bg-white rounded-xl shadow p-4">
        <h2 className="text-lg font-bold mb-4 text-blue-600">
          Quantidade de Voos por Destino
        </h2>
        <Bar data={barData} />
      </div>
    </div>
  );
}
