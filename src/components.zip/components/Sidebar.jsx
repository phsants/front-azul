import { Home, BarChart2, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Sidebar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    navigate("/login");
  };

  return (
    <div className="h-screen w-64 bg-blue-600 text-white flex flex-col">
      <div className="text-2xl font-bold px-6 py-4 border-b border-blue-500">
        UseTravel
      </div>

      <nav className="flex-1 px-4 py-6 space-y-4">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-3 hover:bg-blue-700 p-2 rounded"
        >
          <Home size={20} /> Dashboard
        </button>
        <button
          className="flex items-center gap-3 hover:bg-blue-700 p-2 rounded"
        >
          <BarChart2 size={20} /> Relatórios
        </button>
      </nav>

      <div className="px-4 py-6">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full hover:bg-blue-700 p-2 rounded"
        >
          <LogOut size={20} /> Logout
        </button>
      </div>
    </div>
  );
}
