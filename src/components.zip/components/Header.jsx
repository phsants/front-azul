export default function Header() {
  const usuario = localStorage.getItem("username") || "Usuário";

  return (
    <header className="w-full h-16 bg-white shadow flex items-center justify-between px-6">
      <h1 className="text-xl font-semibold text-blue-600">
        Dashboard de Voos
      </h1>
      <div className="text-sm text-gray-700">
        Olá, <span className="font-semibold">{usuario}</span>
      </div>
    </header>
  );
}
