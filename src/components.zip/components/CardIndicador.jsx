export function CardIndicador({ titulo, valor, icone, cor = "blue" }) {
  const cores = {
    blue: "text-blue-600",
    green: "text-green-600",
    red: "text-red-600",
    yellow: "text-yellow-500",
    gray: "text-gray-600",
  };

  return (
    <div className="flex items-center bg-white rounded-xl shadow p-4 w-[250px] gap-4">
      {icone && (
        <div className={`text-3xl ${cores[cor]}`}>
          {icone}
        </div>
      )}
      <div>
        <h2 className="text-sm text-gray-500">{titulo}</h2>
        <p className={`text-2xl font-semibold ${cores[cor]}`}>
          {valor}
        </p>
      </div>
    </div>
  );
}
