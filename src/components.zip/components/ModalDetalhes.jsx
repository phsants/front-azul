export function ModalDetalhes({ aberto, onClose, dados }) {
  if (!aberto || !dados) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-blue-600">
            Detalhes do Voo
          </h2>
          <button
            onClick={onClose}
            className="text-red-600 font-bold hover:underline"
          >
            Fechar
          </button>
        </div>

        <div className="space-y-2">
          <div>
            <strong>Origem:</strong> {dados.origem}
          </div>
          <div>
            <strong>Destino:</strong> {dados.destino}
          </div>
          <div>
            <strong>Companhia:</strong> {dados.companhia}
          </div>
          <div>
            <strong>Tipo de Voo:</strong> {dados.tipo_voo}
          </div>
          <div>
            <strong>Data de Ida:</strong> {dados.data_saida}
          </div>
          <div>
            <strong>Data de Volta:</strong> {dados.data_volta}
          </div>
          <div>
            <strong>Preço:</strong> R$ {dados.preco}
          </div>
          <div>
            <strong>Cliente:</strong> {dados.cliente_nome}
          </div>
          <div>
            <strong>Hotel:</strong> {dados.nome_hotel}
          </div>
          <div>
            <strong>Qtd de Adultos:</strong> {dados.adultos}
          </div>
          <div>
            <strong>Qtd de Crianças:</strong> {dados.criancas}
          </div>
          <div>
            <strong>Qtd de Bebês:</strong> {dados.bebes}
          </div>
        </div>
      </div>
    </div>
  );
}
