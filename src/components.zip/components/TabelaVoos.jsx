export function TabelaVoos({ dados, onRowClick }) {
  return (
    <div className="bg-white rounded-xl shadow p-4 overflow-auto">
      <h2 className="text-lg font-bold mb-4 text-blue-600">Tabela de Voos</h2>
      <table className="min-w-full">
        <thead className="bg-blue-600">
          <tr>
            <th className="px-4 py-2 text-left text-white">Origem</th>
            <th className="px-4 py-2 text-left text-white">Destino</th>
            <th className="px-4 py-2 text-left text-white">Companhia</th>
            <th className="px-4 py-2 text-left text-white">Tipo</th>
            <th className="px-4 py-2 text-left text-white">Data</th>
            <th className="px-4 py-2 text-left text-white">Preço (R$)</th>
          </tr>
        </thead>
        <tbody>
          {dados.length === 0 && (
            <tr>
              <td colSpan="6" className="text-center py-4 text-gray-500">
                Nenhum dado encontrado.
              </td>
            </tr>
          )}

          {dados.map((v) => (
            <tr
              key={v.id}
              className="hover:bg-gray-100 cursor-pointer even:bg-gray-50"
              onClick={() => onRowClick && onRowClick(v)}
            >
              <td className="px-4 py-2">{v.origem}</td>
              <td className="px-4 py-2">{v.destino}</td>
              <td className="px-4 py-2">{v.companhia}</td>
              <td className="px-4 py-2">{v.tipo_voo}</td>
              <td className="px-4 py-2">{v.data_saida}</td>
              <td className="px-4 py-2">R$ {v.preco}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
